import UIKit

final class Name {
    var value: Name
    
    init(_ x: Name) {
        value = x
    }
}


struct Human {
    private var name: Name //ref
    var secondName: String //value
    init(_ x: Name, newName: String) {
        name = Name(x)
        secondName = newName
    }

    var myType: Name {
        get { return name.value }
        set {
            if (!isKnownUniquelyReferenced(&name)) {
                name = Name(newValue)
                return
            }
            name.value = newValue
        }
    }
}
